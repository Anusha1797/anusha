package com.cts.jdbcexample;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JDBCExample {

	public static void main(String[] args) throws Exception {
	
	 Scanner scan = new Scanner(System.in);
	 Scanner scan1 = new Scanner(System.in);
	 SelectQuery sq = new SelectQuery();
	 InsertQuery iq = new InsertQuery();
	 UpdateQuery uq = new UpdateQuery();
	 DeleteQuery dq = new DeleteQuery();
	 Connection connection = DBConnection.getConnection();
	 String con = "y";
	 while(con.equalsIgnoreCase("y")) {
	 System.out.println("Enter Choice:\n1.ViewData\n2.Insert Data\n3.Updated Data\n4.Delete Data\n");
	 int choice = scan.nextInt();
	 switch(String.valueOf(choice))					
	 {
		case "1": {sq.select();} break;
		case "2": {iq.insert();} break;
		case "3": {uq.update();} break;
		case "4": {dq.delete();} break;
		default : {System.out.println("Wrong Choice");} break;
	}
		System.out.println("\n\nContinue? (Y/N): ");
		con = scan1.nextLine();
	 }
	}
}

//For DB Connection		
class DBConnection {
	public static Connection getConnection() {
	Connection connection = null;
	try {
		  Class.forName("com.mysql.cj.jdbc.Driver");
		  connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","root");
		}
	catch(ClassNotFoundException e) {
		  e.printStackTrace();
		}
	catch(SQLException e) {
		  e.printStackTrace();
		}
	    return connection;
	}
}

//For Deleting
class DeleteQuery {
	 public void delete() throws Exception 
	 {
	   Connection connection = DBConnection.getConnection();
	   Scanner sc = new Scanner(System.in);
	   System.out.println("1.Delete a record\n2.Clear Table\n");
	   int ch = sc.nextInt();
	   if(ch==1) 
	   {
		 System.out.println("Enter Id: ");
		 int id = sc.nextInt();
		 Statement st = connection.createStatement();
		 String sql = "delete from employee where empid= "+id;
		 st.executeUpdate(sql);
		 st.close();
		 connection.close();
		 System.out.println("\nDelete Successfull");
		}
	 else if (ch==2)
	    {
		  Statement st = connection.createStatement();
		  String sql = "truncate table employee";
		  System.out.println(sql);
		  st.executeUpdate(sql);
		  st.close();
		  connection.close();
		  System.out.println("\nTable cleared");
		 }
	}
}

//For Updating
class UpdateQuery {
   public void update() throws Exception 
   {
	 Connection connection = DBConnection.getConnection();
	 Scanner sc = new Scanner(System.in);
	 System.out.println("Insert employee id to update record: ");
	 int id = sc.nextInt();
	 System.out.println("Enter new name >>");
	 String name = sc.next();
	 Statement st = connection.createStatement();
	 String sql = "Update employee set empname= '"+name+"'where empid= "+id;
	 st.executeUpdate(sql);
	 st.close();
	 connection.close();
	 System.out.println("Update Successful");
	}
}

//For Inserting
class InsertQuery {
	public void insert() throws Exception 
	{
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter employee Details >> ");
	  int id = sc.nextInt();
	  System.out.println("Enter employee name >>");
	  String name = sc.next();
	  System.out.println("Enter employee designation");
	  String designation = sc.next();
	  Connection connection = DBConnection.getConnection();
	  Statement st = connection.createStatement();
	  String sql = "insert into employee(empid,empname,designation) values(' "+id+" ',' "+name+" ',' "+designation+" ')";
	  st.executeUpdate(sql);
	  st.close();
	  connection.close();
	  System.out.println("Insert Successful");	
	}
}

//For Viewing
class SelectQuery {
	public void select() throws Exception 
	{
	  Connection connection = DBConnection.getConnection();
	  Scanner sc = new Scanner(System.in);
	  Statement st = connection.createStatement();
	  System.out.println("1.View the table\n");
	  int ch = sc.nextInt();
	  if(ch==1)
	  {
		String sql = "select * from employee";
		ResultSet rs = st.executeQuery(sql);
		if(rs == null)
		{
		  System.out.println("Table empty");			
		}
		System.out.println("ID\t\tName \n");
		System.out.println("--\t\t----\n\n");
		while(rs.next()) 
		{
		  System.out.println(rs.getInt(1)+"\t\t"+rs.getString("empname"));
		}
	    rs.close();
		st.close();
	    connection.close();
		}
	}
		
}		
			   
		
		
					
				
				
			


