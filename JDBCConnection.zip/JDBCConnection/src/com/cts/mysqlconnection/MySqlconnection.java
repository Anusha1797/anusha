package com.cts.mysqlconnection;
import java.sql.*;

public class MySqlconnection {

	public static void main(String[] args) {
		Connection connection  = null;
		try {
			String driverName = "com.mysql.cj.jdbc.Driver";
			Class.forName(driverName);
			
			String servername = "localhost";
			String schema = "sample";
			String url ="jdbc:mysql://"+ servername + "/" + schema;
			String username = "root";
			String password = "root";		
		    connection = DriverManager.getConnection(url,username,password);
		    System.out.println("Succesfully connected to the database");
		}
		catch(ClassNotFoundException e) {
			System.out.println("Could not find the database driver"+ e.getMessage());
		}
		catch(SQLException e) {
			System.out.println("Could not connect  to the database"+e.getMessage());
		}
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("select * from employee");
			while(rs.next()) {
				//String data = rs.getString(1);
				//System.out.println("Fetching data by column index for row"+ rs.getRow()+":"+data);
				//data = rs.getString("empname");
				//System.out.println("Fetching data by column name for row"+rs.getRow()+":"+data);
				int empid = rs.getInt("empid");
				String empname = rs.getString("empname");
				String designation = rs.getString("role");
				
				System.out.println(empid+" "+empname+" "+designation);
				
			}
			stmt.close();
			connection.close();
		}
			catch(SQLException e) 
			{
				System.out.println("Could not retrieve the data from database"+e.getMessage());
			}

}
}
