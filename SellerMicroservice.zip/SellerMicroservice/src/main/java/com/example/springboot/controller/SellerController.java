package com.example.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot.entity.Seller;
import com.example.springboot.service.SellerService;

@RestController
@CrossOrigin(origins="*")
public class SellerController 
{
	@Autowired
	private SellerService service;
	
	@RequestMapping("/getallsellers")
	public List<Seller> getAllSellers()
	{
		return service.getAllSellers();
	}
	
	@RequestMapping(value="/addseller",method=RequestMethod.POST,produces="application/json")
	public Seller addSeller(@RequestBody Seller seller)
	{
		return service.addseller(seller);
	}

}
