package com.example.springboot.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seller")
public class Seller implements Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int sellerid;
	private String username;
	private String password;
	private String companyname;
	private String briefaboutcompany;
	private String postaladdress;
	private String website;
	private String emailid;
	private String contactnumber;
	
	public Seller()
	{
		
	}

	public Seller(int sellerid, String username, String password, String companyname, String briefaboutcompany,
			String postaladdress, String website, String emailid, String contactnumber) {
		super();
		this.sellerid = sellerid;
		this.username = username;
		this.password = password;
		this.companyname = companyname;
		this.briefaboutcompany = briefaboutcompany;
		this.postaladdress = postaladdress;
		this.website = website;
		this.emailid = emailid;
		this.contactnumber = contactnumber;
	}

	public int getSellerid() {
		return sellerid;
	}

	public void setSellerid(int sellerid) {
		this.sellerid = sellerid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public String getBriefaboutcompany() {
		return briefaboutcompany;
	}

	public void setBriefaboutcompany(String briefaboutcompany) {
		this.briefaboutcompany = briefaboutcompany;
	}

	public String getPostaladdress() {
		return postaladdress;
	}

	public void setPostaladdress(String postaladdress) {
		this.postaladdress = postaladdress;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	@Override
	public String toString() {
		return "Seller [sellerid=" + sellerid + ", username=" + username + ", password=" + password + ", companyname="
				+ companyname + ", briefaboutcompany=" + briefaboutcompany + ", postaladdress=" + postaladdress
				+ ", website=" + website + ", emailid=" + emailid + ", contactnumber=" + contactnumber + "]";
	}
	
	

}
