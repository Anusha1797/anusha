package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.DiseaseEntity;

import com.cts.service.diseaseService;

@RestController
@RequestMapping("/disease")
public class DiseaseController {
	@Autowired
	private diseaseService service;
	
	@RequestMapping(value="addDisease/{adminid}", method=RequestMethod.POST,produces="application/json")
	public String addDisease(@PathVariable(value="adminid") int aid,@RequestBody DiseaseEntity disease) {
		
		service.addDisease(disease,aid);
		return "DISEASES ADDED";
	
	}
	@RequestMapping(value="/findByName/{diseasename}")
	public DiseaseEntity findByName(@PathVariable(value="diseasename") String dname,@RequestBody DiseaseEntity disease)
		
	{
		return service.search(dname);
	}
	
   @RequestMapping(value="/update/{adminid}")
   public DiseaseEntity update(@PathVariable(value="adminid") int aid,@RequestBody DiseaseEntity disease)
   {
	return service.update(aid,disease);
	   
   }
   @RequestMapping("getAllDiseases/{adminid}")
   public List<DiseaseEntity> getAllDiseases(@PathVariable(value="adminid") int aid){
	return service.getAllDiseases(aid);
	 }
  @RequestMapping(value="/delete/{adminid}")
   public void delete(@PathVariable(value="adminid") int aid)
   {
	 service.delete(aid);
	   
   }
	

}
