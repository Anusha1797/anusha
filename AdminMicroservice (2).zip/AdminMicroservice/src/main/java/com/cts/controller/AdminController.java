package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.AdminEntity;

import com.cts.service.AdminService;
@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminService service;
	
	@RequestMapping(value="/addAdmin")
	public AdminEntity addAdmin(@RequestBody AdminEntity admin) {
		return service.addAdmin(admin);
	
	}
	
	@RequestMapping(value="/getAllAdmins")
	public List<AdminEntity> getAllAdmins(){
		return service.getAllAdmins();
		
	}
	
}

