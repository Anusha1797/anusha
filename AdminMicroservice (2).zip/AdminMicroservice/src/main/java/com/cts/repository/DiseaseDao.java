package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.model.DiseaseEntity;
@Repository
public interface DiseaseDao extends JpaRepository<DiseaseEntity,Integer> {

	
	@Query(value="FROM DiseaseEntity where Diseasename like %:name%")
	public DiseaseEntity findByName(@Param("name") String dname);
	
	@Query(value="SELECT * FROM disease where admin_id=:aid",nativeQuery=true)
	public List<DiseaseEntity> findAllById(int aid);

}
