package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@Table(name = "Fruit")
public class FruitsEntity implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int fid;
	private String Fruitname;
	private String Diseasename;
	private float Price;
	private String Remediesdescription;
	@ManyToOne
	@JoinColumn(name="admin_key")
	private AdminEntity Id;
	

	public FruitsEntity() {

	}


	public int getFid() {
		return fid;
	}


	public void setFid(int fid) {
		this.fid = fid;
	}


	public String getFruitname() {
		return Fruitname;
	}


	public void setFruitname(String fruitname) {
		Fruitname = fruitname;
	}


	public String getDiseasename() {
		return Diseasename;
	}


	public void setDiseasename(String diseasename) {
		Diseasename = diseasename;
	}


	public float getPrice() {
		return Price;
	}


	public void setPrice(float price) {
		Price = price;
	}


	public String getRemediesdescription() {
		return Remediesdescription;
	}


	public void setRemediesdescription(String remediesdescription) {
		Remediesdescription = remediesdescription;
	}


	public AdminEntity getId() {
		return Id;
	}


	public void setId(AdminEntity id) {
		Id = id;
	}


	@Override
	public String toString() {
		return "FruitsEntity [fid=" + fid + ", Fruitname=" + Fruitname + ", Diseasename=" + Diseasename + ", Price="
				+ Price + ", Remediesdescription=" + Remediesdescription + ", Id=" + Id + "]";
	}


	
}
