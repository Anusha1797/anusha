package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.FruitsEntity;
import com.cts.service.FruitService;
@RestController
@RequestMapping("/fruit")
public class FruitController {
	
		@Autowired(required = true)
		private FruitService service;
		
		@RequestMapping(value="/addFruit/{adminid}", method=RequestMethod.POST,produces="application/json")
		public String addFruit(@PathVariable(value="adminid") int aid,@RequestBody FruitsEntity fruit) {
			
			service.addFruit(fruit,aid);
			return "FRUITS ADDED";
		
		}
		
		@RequestMapping(value="/findByName/{fruitname}")
		public FruitsEntity findByName(@PathVariable(value="fruitname") String fname,@RequestBody FruitsEntity fruit)
			
		{
			return service.search(fname);
		}
		
	 /*  @RequestMapping(value="/update/{adminid}")
	   public FruitsEntity update(@PathVariable(value="adminid") int aid,@RequestBody FruitsEntity fruit)
	   {
		return service.update(aid,fruit);
		   
	   }*/
	   @RequestMapping("getAllFruits/{adminid}")
	   public List<FruitsEntity> getAllFruits(@PathVariable(value="adminid") int aid){
		return service.getAllFruits(aid);
		 }
	  
	   
	   
}


