package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.AdminEntity;
import com.cts.model.FruitsEntity;
import com.cts.repository.AdminDao;
import com.cts.repository.FruitDao;

@Service
public class FruitService {
	
	@Autowired
	private FruitDao fruitdao;
	@Autowired
	private AdminDao admindao;
	
	public FruitsEntity addFruit(FruitsEntity fruit, int aid) {
		AdminEntity admin=admindao.getOne(aid);
		
		fruit.setId(admin);
		return fruitdao.save(fruit);
	
	}




	public FruitsEntity search(String fname) {
		return fruitdao.findByName(fname);
		
	}


	public List<FruitsEntity> getAllFruits(int aid) {
		
		return fruitdao.findAllById(aid);
	}



	public void delete(int aid) {
		fruitdao.deleteById(aid);
		
	}


	public FruitsEntity update(int aid, FruitsEntity fruit) {
		FruitsEntity fruit1=fruitdao.getOne(aid);
		float price=fruit.getPrice();
		fruit1.setPrice(price);
		return fruitdao.save(fruit1);
		
	}
	
	

}
