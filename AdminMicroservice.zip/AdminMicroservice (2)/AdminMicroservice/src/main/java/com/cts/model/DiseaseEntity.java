package com.cts.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
@Table(name = "disease")
public class DiseaseEntity implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int did;
	private String Diseasename;
	private String type;
	private String Diseaseremedy;
	@ManyToOne
	@JoinColumn(name="admin_id")
	private AdminEntity Id;

	public DiseaseEntity() {

	}

	public String getDiseasename() {
		return Diseasename;
	}

	public void setDiseasename(String diseasename) {
		Diseasename = diseasename;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDiseaseremedy() {
		return Diseaseremedy;
	}

	public void setDiseaseremedy(String diseaseremedy) {
		Diseaseremedy = diseaseremedy;
	}
	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public AdminEntity getId() {
		return Id;
	}

	public void setId(AdminEntity id) {
		Id = id;
	}

	@Override
	public String toString() {
		return "DiseaseEntity [did=" + did + ", Diseasename=" + Diseasename + ", type=" + type + ", Diseaseremedy="
				+ Diseaseremedy + ", Id=" + Id + "]";
	}


	

	
}