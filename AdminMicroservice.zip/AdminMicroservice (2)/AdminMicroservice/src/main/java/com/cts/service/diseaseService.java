package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.AdminEntity;
import com.cts.model.DiseaseEntity;
import com.cts.model.FruitsEntity;
import com.cts.repository.AdminDao;
import com.cts.repository.DiseaseDao;

@Service
public class diseaseService {
	@Autowired
	private DiseaseDao diseasedao;
	@Autowired
	private AdminDao admindao;
	

	public DiseaseEntity addDisease(DiseaseEntity disease, int aid) {
AdminEntity admin=admindao.getOne(aid);
		
		disease.setId(admin);
		return diseasedao.save(disease);
		
	}

	public DiseaseEntity search(String dname) {
		return diseasedao.findByName(dname);
	}

	public DiseaseEntity update(int aid, DiseaseEntity disease) {
		DiseaseEntity diseases=diseasedao.getOne(aid);
		String type=disease.getType();
		diseases.setType(type);
		return diseasedao.save(diseases);
	}

	public List<DiseaseEntity> getAllDiseases(int aid) {
		return diseasedao.findAllById(aid);
	}

	public void delete(int aid) {
		diseasedao.deleteById(aid);
		
	}

	
}
