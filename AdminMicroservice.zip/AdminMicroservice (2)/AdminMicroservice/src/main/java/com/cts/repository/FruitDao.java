package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.model.FruitsEntity;
@Repository
public interface FruitDao extends JpaRepository<FruitsEntity,Integer> {
@Query(value="FROM FruitsEntity where Fruitname like %:name%")
public FruitsEntity findByName(@Param("name") String fname);

//public FruitsEntity update(FruitsEntity fruit);


@Query(value="SELECT * FROM fruit where admin_key=:aid",nativeQuery=true)
public List<FruitsEntity> findAllById(int aid);



	

}
