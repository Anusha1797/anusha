package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.AdminEntity;
import com.cts.repository.AdminDao;
@Service
public class AdminService {
	@Autowired
	private AdminDao admindao;
	
	
		public AdminEntity addAdmin(AdminEntity admin) {
			return admindao.save(admin);
		}


		public List<AdminEntity> getAllAdmins() {
			
			return admindao.findAll();
		}

}
