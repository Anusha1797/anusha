package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.AdminEntity;
import com.cts.model.Employee;
import com.cts.repository.AdminDao;
import com.cts.repository.EmployeeDao;
import com.cts.service.EmployeeService;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeDao empdao;
	@Autowired
	private AdminDao admindao;

	public Employee addemployee(int aid, Employee employee) {
		AdminEntity admin = admindao.getOne(aid);
		 employee.setAdmin(admin);
		return empdao.save(employee);
	}

	public List<Employee> getAllEmployees(int aid) {
		return empdao.findAllById(aid);
	}

}
