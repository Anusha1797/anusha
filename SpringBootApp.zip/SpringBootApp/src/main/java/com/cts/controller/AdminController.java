package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cts.model.AdminEntity;
import com.cts.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminService adminservice;
	
	@RequestMapping(value="/addadmin")
	public AdminEntity addAdmin(@RequestBody AdminEntity admin)
	{
		return adminservice.addAdmin(admin);
	}
	
	@RequestMapping(value="/getalladmins")
	public List<AdminEntity> getAllAdmins()
	{
		return adminservice.getAllAdmin();
	}
	@RequestMapping(value="getadmin/{username}/{password}")
	public AdminEntity getadmin(@PathVariable(value="username") String uname, @PathVariable(value="password") String password)

	{
		return adminservice.getadmin(uname,password);
	}
	@PostMapping(value= "/login")
	public AdminEntity loginUser(@RequestBody AdminEntity admin) throws Exception {
		String tempEmailId = admin.getEmail();
		String  tempPass = admin.getPassword();
		AdminEntity adminentity = null;
		if(tempEmailId != null && tempPass != null) {
			adminentity = adminservice.fetchUserByEmailAndPassword(tempEmailId, tempPass);
			
		}
		if(adminentity == null) {
			throw new Exception("Bad Credentials");
		}
		return adminentity;
		
		
	}		
	
}

