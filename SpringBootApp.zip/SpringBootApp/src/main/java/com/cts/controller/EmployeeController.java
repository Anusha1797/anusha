package com.cts.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Employee;
import com.cts.service.EmployeeService;

@RestController
@RequestMapping(value="/admin")
public class EmployeeController {
    
	@Autowired
	private EmployeeService empservice;
	
	@RequestMapping(value = "addemployee/{adminid}", method=RequestMethod.POST,produces="application/json")
	public String addemployee(@PathVariable(value="adminid") int aid, @RequestBody Employee employee){
		 empservice.addemployee(aid,employee);
		 return "Employee added";
	}
	@RequestMapping("getAllEmployees/{adminid}")
	public List<Employee> getAllEmployees(@PathVariable(value="adminid") int aid) {
		return empservice.getAllEmployees(aid);
	}
	
}
