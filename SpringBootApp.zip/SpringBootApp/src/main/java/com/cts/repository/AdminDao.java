package com.cts.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.model.AdminEntity;

@Repository
public interface AdminDao extends JpaRepository<AdminEntity,Integer>  {

	AdminEntity findByUsername(String username);

public Optional<AdminEntity> findByUsernameAndPassword(String uname, String password);

public AdminEntity findByEmailAndPassword(String email, String password);


}
